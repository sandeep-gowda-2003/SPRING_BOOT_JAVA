package com.infosys;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MsApplication2Application {

	public static void main(String[] args) {
		SpringApplication.run(MsApplication2Application.class, args);
	}

}
