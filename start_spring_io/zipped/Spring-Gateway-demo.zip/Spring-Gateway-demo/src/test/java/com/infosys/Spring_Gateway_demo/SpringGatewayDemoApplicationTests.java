package com.infosys.Spring_Gateway_demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringGatewayDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
