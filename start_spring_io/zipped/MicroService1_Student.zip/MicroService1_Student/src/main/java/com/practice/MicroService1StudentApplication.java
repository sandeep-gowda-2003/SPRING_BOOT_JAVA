package com.practice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MicroService1StudentApplication {

	public static void main(String[] args) {
		SpringApplication.run(MicroService1StudentApplication.class, args);
	}

}
