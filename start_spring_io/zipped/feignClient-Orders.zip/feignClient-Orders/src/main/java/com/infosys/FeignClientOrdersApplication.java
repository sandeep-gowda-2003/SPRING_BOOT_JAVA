package com.infosys;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FeignClientOrdersApplication {

	public static void main(String[] args) {
		SpringApplication.run(FeignClientOrdersApplication.class, args);
	}

}
