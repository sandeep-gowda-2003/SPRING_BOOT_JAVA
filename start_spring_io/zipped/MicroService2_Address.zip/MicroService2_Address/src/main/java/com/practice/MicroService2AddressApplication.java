package com.practice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MicroService2AddressApplication {

	public static void main(String[] args) {
		SpringApplication.run(MicroService2AddressApplication.class, args);
	}

}
