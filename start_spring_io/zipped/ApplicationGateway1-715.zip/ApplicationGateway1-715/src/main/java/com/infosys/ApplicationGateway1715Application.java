package com.infosys;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ApplicationGateway1715Application {

	public static void main(String[] args) {
		SpringApplication.run(ApplicationGateway1715Application.class, args);
	}

}
