package com.infosys.MVC_repo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MvcRepoApplicationTests {

	@Test
	void contextLoads() {
	}

}
