package com.infosys.Exer_rest;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ExerRestApplicationTests {

	@Test
	void contextLoads() {
	}

}
