package com.infosys.Blog_Rest_ExceptionHandling;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BlogRestExceptionHandlingApplicationTests {

	@Test
	void contextLoads() {
	}

}
